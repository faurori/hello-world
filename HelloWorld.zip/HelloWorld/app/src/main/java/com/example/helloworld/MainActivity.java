package com.example.helloworld;


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements OnClickListener {
    Button toast;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toast = (Button) findViewById(R.id.button);

        toast.setOnClickListener(this);
    }
    @Override
    public void onClick(View v) {
        Toast.makeText(MainActivity.this, "Thank you for a fantastic Mobile Computing Course!", Toast.LENGTH_LONG).show();
    }

    }








